﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication6.Models;

namespace MvcApplication6.Controllers
{
    public class adminController : Controller
    {
        private TelephonesDBEntities db = new TelephonesDBEntities();
        //
        // GET: /admin/

        [Authorize(Roles = "administrators")]
        public ActionResult Index()
        {
            var telephones = (from telephone in db.Telephones select telephone).ToList();
            return View(telephones);
        }

        //
        // GET: /admin/Details/5
               [Authorize(Roles = "administrators")]
        public ActionResult Details(int id)
        {
            var telephoneDetails = (from telephone in db.Telephones
                                    where
                                        telephone.id_tel == id
                                    select telephone).First();
            return View(telephoneDetails);
        }

        //
        // GET: /admin/Create
               [Authorize(Roles = "administrators")]
        public ActionResult Create()
        {
            Telephone tel = new Telephone();
            return View(tel);
        } 

        //
        // POST: /admin/Create
              
        [HttpPost]
        [Authorize(Roles = "administrators")]
        public ActionResult Create(Telephone tel)
        {
            try
            {
                // TODO: Add insert logic here
                if (ModelState.IsValid)
                {
                    db.AddToTelephones(tel);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
            }
            catch(Exception e)
            {
                ModelState.AddModelError(String.Empty,e);
            }           return View(tel);
        }
        
        //
        // GET: /admin/Edit/5
        [Authorize(Roles = "administrators")]
        public ActionResult Edit(int id)
        {
            var telephoneEdit = (from telephone in db.Telephones
                                    where
                                        telephone.id_tel == id
                                    select telephone).First();
            return View(telephoneEdit);
        }

        //
        // POST: /admin/Edit/5
               
        [HttpPost]
        [Authorize(Roles = "administrators")]
        public ActionResult Edit(int id, FormCollection collection)
        {
            var telephoneEdit = (from telephone in db.Telephones
                                 where
                                     telephone.id_tel == id
                                 select telephone).First();
            try
            {
                // TODO: Add update logic here
                UpdateModel(telephoneEdit);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View(telephoneEdit);
            }
        }

        //
        // GET: /admin/Delete/5
        [Authorize(Roles = "administrators")]
        public ActionResult Delete(int id)
        {
            var telephoneDel = (from telephone in db.Telephones
                                 where
                                     telephone.id_tel == id
                                 select telephone).First();
            return View(telephoneDel);
        }

        //
        // POST: /admin/Delete/5
              
        [HttpPost] 
        [Authorize(Roles = "administrators")]
        public ActionResult Delete(int id, FormCollection collection)
        {
            var telephoneDel = (from telephone in db.Telephones
                                where
                                    telephone.id_tel == id
                                select telephone).First();
            try
            {
                db.DeleteObject(telephoneDel);
                db.SaveChanges();
                // TODO: Add delete logic here
 
                return RedirectToAction("Index");
            }
            catch
            {
                return View(telephoneDel);
            }
        }
    }
}
