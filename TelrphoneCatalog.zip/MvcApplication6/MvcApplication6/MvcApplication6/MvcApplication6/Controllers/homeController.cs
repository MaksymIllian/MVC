﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication6.Models;

namespace MvcApplication6.Controllers
{
    public class homeController : Controller
    {
        private TelephonesDBEntities db = new TelephonesDBEntities();
        private int size = 10;
        //
        // GET: /home/

        public ActionResult Index(int pagenum = 0)
        {
            var telephones = (from telephone in db.Telephones orderby telephone.name_company select telephone).ToList();
            return View(telephones);
        }
        public ActionResult Details(int id)
        {
            var telephoneDetails = (from telephone in db.Telephones where 
                                        telephone.id_tel==id 
                                    select telephone).First();
            return View(telephoneDetails);
        }

    }
}
