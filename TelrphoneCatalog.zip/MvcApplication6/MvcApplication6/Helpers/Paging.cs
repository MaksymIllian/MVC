﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using System.Text;

namespace MvcApplication6.Helpers
{
    public static class Paging
    {
        public static MvcHtmlString PagingNavigator(this HtmlHelper help, int pageNum, int itemsCount , int size)
        {
            StringBuilder sb = new StringBuilder();
            if (pageNum > 0)
            {
                sb.Append(help.ActionLink("<", "Index", new { pageNum = (pageNum - 1) }));
            }
            else 
            {
                sb.Append(HttpUtility.HtmlEncode("<"));
            }
            sb.Append(" ");
            int pagesCount = (int)Math.Ceiling((double) itemsCount / size);
            if (pageNum < pagesCount-1)
            {
                sb.Append(help.ActionLink(">", "Index", new { pageNum = (pageNum + 1) }));
            }
            else 
            {
                sb.Append(HttpUtility.HtmlEncode(">"));
            }
            return MvcHtmlString.Create(sb.ToString());
        }
    }
}