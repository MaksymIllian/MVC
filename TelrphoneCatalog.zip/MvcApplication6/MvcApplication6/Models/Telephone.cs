﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using System.ComponentModel;

namespace MvcApplication6.Models
{
    [MetadataType(typeof(TelMetadata))]
    public partial class Telephone
    {
        [Bind(Exclude="id_tel")]
        public class TelMetadata
        {
            [ScaffoldColumn(false)]
            public int id_tel { get; set; }

            [DisplayName("Company")]
            [Required(ErrorMessage="Error")]
            [DisplayFormat(ConvertEmptyStringToNull=false)]
            [StringLength(10)]
            public string name_company { get; set; }

            [DisplayName("Number of model")]
            [Required(ErrorMessage = "Error")]
            [DisplayFormat(ConvertEmptyStringToNull = false)]
            [StringLength(10)]
            public string number { get; set; }

            [DisplayName("GPRS")]
            [Required(ErrorMessage = "Error")]
            [DisplayFormat(ConvertEmptyStringToNull = false)]
            [StringLength(10)]
            public string GPRS { get; set; }

            [DisplayName("FM")]
            [Required(ErrorMessage = "Error")]
            [DisplayFormat(ConvertEmptyStringToNull = false)]
            [StringLength(10)]
            public string FM { get; set; }

            [DisplayName("Camera")]
            [Required(ErrorMessage = "Error")]
            [DisplayFormat(ConvertEmptyStringToNull = false)]
            [StringLength(10)]
            public string Camera { get; set; }

            [DisplayName("Cost")]
            [Required(ErrorMessage = "Error cost")]
            [DisplayFormat(DataFormatString= "{0:F2}" , ApplyFormatInEditMode = true)]
           // [StringLength(10)]
            [Range(0,10000,ErrorMessage = "cost must be between 0 and 10 000")]
            public decimal Cost { get; set; }
        }
    }
}