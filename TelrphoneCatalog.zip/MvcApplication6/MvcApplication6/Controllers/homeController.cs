﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication6.Models;

namespace MvcApplication6.Controllers
{
    public class homeController : Controller
    {
        private TelephonesDBEntities db = new TelephonesDBEntities();
        public int size = 10;
        //
        // GET: /home/

        public ActionResult Index(int pagenum = 0)
        {
            ViewData["pageNum"] = pagenum;
            ViewData["itemsCount"] = db.Telephones.Count();
            ViewData["size"] = size;
            var telephones = (from telephone in db.Telephones orderby telephone.id_tel select telephone).
                Skip(size*pagenum).Take(size).ToList();
            return View(telephones);
        }
        public ActionResult Index1(int pagenum = 0)
        {
            ViewData["pageNum"] = pagenum;
            ViewData["itemsCount"] = db.Telephones.Count();
            ViewData["size"] = size;
            var telephones = (from telephone in db.Telephones orderby telephone.name_company select telephone).
                Skip(size * pagenum).Take(size).ToList();
            return View(telephones);
        }
        public ActionResult Index2(int pagenum = 0)
        {
            ViewData["pageNum"] = pagenum;
            ViewData["itemsCount"] = db.Telephones.Count();
            ViewData["size"] = size;
            var telephones = (from telephone in db.Telephones orderby telephone.Cost select telephone).
                Skip(size * pagenum).Take(size).ToList();
            return View(telephones);
        }
        public ActionResult Details(int id)
        {
            var telephoneDetails = (from telephone in db.Telephones where 
                                        telephone.id_tel==id 
                                    select telephone).First();
            return View(telephoneDetails);
        }

    }
}
