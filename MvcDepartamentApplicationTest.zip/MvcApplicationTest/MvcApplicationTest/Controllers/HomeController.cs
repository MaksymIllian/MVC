﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplicationTest.Models;

namespace MvcApplicationTest.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        Database1Entities db = new Database1Entities();
        int size = 5;
        public ActionResult Index(int pageNum = 0, int filter = 0)
        {
            ViewData["PageNum"] = pageNum;
            ViewData["PageSize"] = size;
            ViewData["Filter"] = filter;
            var departamements = (from depart in db.Departaments
                                  orderby depart.Id
                                  select depart).ToList();
            ViewData["ItemsCount"] = departamements.Count();
            departamements = (from depart in db.Departaments
                                  orderby depart.Id
                              select depart).Skip(pageNum * size).Take(size).ToList();
            
            if(filter == 1)
                departamements = (from depart in db.Departaments
                                  orderby  depart.Name
                                  select depart).Skip(pageNum * size).Take(size).ToList();
            
            if (!Request.IsAjaxRequest())
            {
                return View(departamements);
            }
            else
            {
                return PartialView("Index", departamements);
            }
        }

        //
        // GET: /Home/Create

        public ActionResult CreateDepart()
        {
            Departament depart = new Departament();
            return View(depart);
        }

        //
        // POST: /Home/Create

        [HttpPost]
        public ActionResult CreateDepart(Departament depart)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var departamements = (from departs in db.Departaments
                                          orderby departs.Id
                                          select departs).ToList();
                    for (int i = 0; i < departamements.Count; i++)
                    {
                        if (depart.Name == departamements[i].Name.ToString().Trim())
                        {
                            ModelState.AddModelError("Name", "Уже существует");
                            return View(depart);
                        }
                    }
                        db.Departaments.Add(depart);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Error", ex);
            }
            return View(depart);
        }

        //
        // GET: /Home/Edit/5

        public ActionResult EditDepart(int id)
        {
            var departEdit = (from depart in db.Departaments
                              where depart.Id == id
                              select depart).First();
            return View(departEdit);
        }

        //
        // POST: /Home/Edit/5

        [HttpPost]
        public ActionResult EditDepart(int id, FormCollection collection)
        {
            var departEdit = (from depart in db.Departaments
                              where depart.Id == id
                              select depart).First();
            try
            {
                UpdateModel(departEdit);
                db.SaveChanges();
                return RedirectToAction("Index");

            }
            catch
            {
                return View(departEdit);
            }
        }

        //
        // GET: /Home/Delete/5

        public ActionResult DeleteDepart(int id)
        {
            var departDelete = (from depart in db.Departaments
                                where depart.Id == id
                                select depart).First();
            return View(departDelete);
        }

        //
        // POST: /Home/Delete/5

        [HttpPost]
        public ActionResult DeleteDepart(int id, FormCollection collection)
        {
            IQueryable<Emploee> departEmployeesDelete = (from emp in db.Emploees
                                                         where emp.Departament == id
                                                         select emp);
            Departament departDelete = db.Departaments.Find(id);

            try
            {
                foreach (Emploee emp in departEmployeesDelete)
                    db.Emploees.Remove(emp);
                db.Departaments.Remove(departDelete);
                db.SaveChanges();
                return RedirectToAction("Index");


            }
            catch
            {
                return View(departDelete);
            }
        }
    }
}
