﻿using MvcApplicationTest.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplicationTest.Controllers
{
    public class EmployeeController : Controller
    {
        //
        // GET: /Employee/
        Database1Entities db = new Database1Entities();
        int sizeEmp = 5;
        public ActionResult Index(int id, int pageNum=0, int filter=0 )
        {
            ViewData["PageNumEmp"] = pageNum;
            ViewData["Depart"] = id;
            ViewData["PageSizeEmp"] = sizeEmp;
            ViewData["Filter"] = filter;
            var emploees = (from emploee in db.Emploees
                            where emploee.Departament == id
                            orderby emploee.Id
                            select emploee).ToList();
            ViewData["ItemsCountEmp"] = emploees.Count();
            emploees = (from emploee in db.Emploees
                        where emploee.Departament == id
                          orderby emploee.Id
                        select emploee).ToList().Skip(pageNum * sizeEmp).Take(sizeEmp).ToList();
            if(filter==1)
                 emploees = (from emploee in db.Emploees
                        where emploee.Departament == id
                        orderby emploee.Name
                        select emploee).ToList().Skip(pageNum * sizeEmp).Take(sizeEmp).ToList();
            if (filter == 2)
                emploees = (from emploee in db.Emploees
                            where emploee.Departament == id
                            orderby emploee.Salary
                            select emploee).ToList().Skip(pageNum * sizeEmp).Take(sizeEmp).ToList();
            if (filter == 3)
                emploees = (from emploee in db.Emploees
                            where emploee.Departament == id
                            orderby emploee.Enrollment
                            select emploee).ToList().Skip(pageNum * sizeEmp).Take(sizeEmp).ToList();
            if (!Request.IsAjaxRequest())
            {
                return View(emploees);
            }
            else
            {
                return PartialView("IndexEmployee", emploees);
            }
        }

        //
        // GET: /Employee/Create

        public ActionResult Create(int depart)
        {
               Emploee emp = new Emploee();
               ViewData["Depart"] = depart;
            return View(emp);
        }

        //
        // POST: /Employee/Create

        [HttpPost]
        public ActionResult Create(Emploee emp, int depart)
        {
            ViewData["Depart"] = depart;
            try
            {
                if (ModelState.IsValid)
                {
                    emp.Departament = depart;
                    db.Emploees.Add(emp);
                    db.SaveChanges();
                    return RedirectToAction("Index", new { id = depart, pageNum = 0 });
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Error", ex);
            }
            return View(emp);
        }
        

        //
        // GET: /Employee/Edit/5

        public ActionResult Edit(int id, int depart)
        {
            var emploeeEdit = (from emploee in db.Emploees
                               where emploee.Id == id
                               select emploee).First();
            ViewData["Depart"] = depart;
            return View(emploeeEdit);
        }

        //
        // POST: /Employee/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, int depart, FormCollection collection)
        {
            var emploeeEdit = (from emploee in db.Emploees
                               where emploee.Id == id
                               select emploee).First();
            ViewData["Depart"] = depart;
            try
            {
                UpdateModel(emploeeEdit);
                db.SaveChanges();
                return RedirectToAction("Index", new { id = depart, pageNum = 0 });

            }
            catch
            {
                return View(emploeeEdit);
            }
        }

        //
        // GET: /Employee/Delete/5

        public ActionResult Delete(int id, int depart)
        {
            var emploeeDelete = (from emploee in db.Emploees
                                 where emploee.Id == id
                                 select emploee).First();
            ViewData["Depart"] = depart;
            return View(emploeeDelete);
        }

        //
        // POST: /Employee/Delete/5

        [HttpPost]
        public ActionResult Delete(int id, int depart, FormCollection collection)
        {
            var emploeeDelete = (from emploee in db.Emploees
                                 where emploee.Id == id
                                 select emploee).First();
            ViewData["Depart"] = depart;
            try
            {
                db.Emploees.Remove(emploeeDelete);
                db.SaveChanges();
                return RedirectToAction("Index", new { id = depart, pageNum = 0 });

            }
            catch
            {
                return View(emploeeDelete);
            }
        }
    }
}
