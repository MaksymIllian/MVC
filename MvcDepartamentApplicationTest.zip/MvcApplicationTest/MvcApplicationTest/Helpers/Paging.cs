﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;

namespace MvcApplicationTest.Helpers
{
    public static class Paging
    {
        public static MvcHtmlString AjaxPagingNavigator(this AjaxHelper helper, string updateTargetId,
            int pageNum, int itemsCount, int pageSize, int filter, int linksPerPage = 10,
            string actionName = "Index", int depart=0)
        {
            StringBuilder sb = new StringBuilder();
            int pagesCount = (int)Math.Ceiling((double)itemsCount / pageSize);
            int startPage = pageNum / linksPerPage * linksPerPage;
            int visiblePages = startPage + linksPerPage <=
                pagesCount ? linksPerPage : pagesCount - startPage;
            AjaxOptions ao = new AjaxOptions();
            ao.UpdateTargetId = updateTargetId;
            ao.OnBegin = "beginUpdate" + updateTargetId;
            ao.OnComplete = "completeUpdate" + updateTargetId;

            string script = @"
    <script type=""text/javascript"">
        var _currentPageNum = -1;

        Sys.Application.add_init(pageInitupdateTargetId);

        function pageInitupdateTargetId() {
            // Enable history
            Sys.Application.set_enableHistory(true);

            // Add Handler for history
            Sys.Application.add_navigate(navigateupdateTargetId);
        }

        function navigateupdateTargetId(sender, e) {
            // Get pageNum from address bar
            var pageNum = e.get_state().pageNum;

            // If pageNum != currentPageNum then navigate
            if (pageNum != _currentPageNum) {
                _currentPageNum = pageNum;
                $('#updateTargetId').load(""?pageNum="" + pageNum);
            }
        }

        function beginUpdateupdateTargetId(args) {
            _currentPageNum = this.getAttribute(""rel"");

            // Add history point
            Sys.Application.addHistoryPoint({ ""pageNum"": _currentPageNum });

            // Animate
            $('#updateTargetId').fadeOut('normal');
        }

        function completeUpdateupdateTargetId() {
            // Animate
            $('#updateTargetId').fadeIn('normal');
        }
    </script>";

            sb.AppendLine(script.Replace("updateTargetId", updateTargetId));

            if (pageNum > 0)
            {
                sb.Append(helper.ActionLink("<<", actionName, new { pageNum = 0, status=filter,depart=depart }, ao, new { rel = 0 }));
                sb.Append(" ");
            }
            else
            {
                sb.Append(HttpUtility.HtmlEncode("<<  "));
            }

            sb.Append(" ");

            for (int i = 0; i < visiblePages; i++)
            {
                int currentPage = i + startPage;
                string currentPageText = (currentPage + 1).ToString();
                if (currentPage != pageNum)
                {
                    sb.Append(helper.ActionLink(currentPageText, actionName,
                        new { pageNum = currentPage, filter = filter }, ao, new { rel = currentPage }));
                }
                else
                {
                    sb.Append(currentPageText);
                }
                sb.Append(" ");
            }

            sb.Append(" ");

            if (pageNum < pagesCount - 1)
            {
                sb.Append(" ");
                sb.Append(helper.ActionLink(">>", actionName, new { pageNum = (pagesCount - 1), filter = filter },
                    ao, new { rel = (pagesCount - 1) }));
            }
            else
            {
                sb.Append(HttpUtility.HtmlEncode("  >>"));
            }

            return MvcHtmlString.Create(sb.ToString());
        }

    
    }
}